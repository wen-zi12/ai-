/* ============================================================
 * Electron 主进程 · 聊吧待办桌面版
 * ============================================================ */
const { app, BrowserWindow, Menu, shell } = require('electron');
const path = require('path');

let mainWindow;

function createWindow() {
  mainWindow = new BrowserWindow({
    width: 1120,
    height: 800,
    minWidth: 900,
    minHeight: 600,
    title: '聊吧待办 · 聊天转待办助手',
    icon: path.join(__dirname, 'icon.png'), // 可选
    webPreferences: {
      nodeIntegration: false,
      contextIsolation: true,
      spellcheck: false
    }
  });

  mainWindow.loadFile(path.join(__dirname, 'index.html'));

  // 外链用系统浏览器打开
  mainWindow.webContents.setWindowOpenHandler(({ url }) => {
    shell.openExternal(url);
    return { action: 'deny' };
  });

  mainWindow.on('closed', () => { mainWindow = null; });
}

// 精简菜单
const template = [
  {
    label: '文件',
    submenu: [
      { label: '重新加载', accelerator: 'CmdOrCtrl+R', click: () => mainWindow && mainWindow.reload() },
      { type: 'separator' },
      { label: '退出', accelerator: 'CmdOrCtrl+Q', click: () => app.quit() }
    ]
  },
  {
    label: '编辑',
    submenu: [
      { role: 'undo', label: '撤销' },
      { role: 'redo', label: '重做' },
      { type: 'separator' },
      { role: 'copy', label: '复制' },
      { role: 'paste', label: '粘贴' },
      { role: 'selectAll', label: '全选' }
    ]
  },
  {
    label: '视图',
    submenu: [
      { role: 'togglefullscreen', label: '全屏切换' },
      { role: 'toggleDevTools', label: '开发者工具' }
    ]
  },
  {
    label: '帮助',
    submenu: [
      { label: '关于', click: () => {
        const { dialog } = require('electron');
        dialog.showMessageBox(mainWindow, {
          type: 'info',
          title: '关于聊吧待办',
          message: '聊吧待办 v' + require('./package.json').version,
          detail: '把聊天记录变成待办事项。聊天与文件仅在本机处理；公众号链接读取为联网功能（App 直连，网页版经公共代理）。'
        });
      }}
    ]
  }
];
Menu.setApplicationMenu(Menu.buildFromTemplate(template));

app.whenReady().then(createWindow);

app.on('window-all-closed', () => {
  if (process.platform !== 'darwin') app.quit();
});
app.on('activate', () => {
  if (BrowserWindow.getAllWindows().length === 0) createWindow();
});
