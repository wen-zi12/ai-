# 聊吧待办 · Android APK

这是用 **Capacitor** 把「聊吧待办」网页应用打包成的 Android 应用，功能与桌面/网页版一致，并做了移动端适配。

## 安装

1. 把 `聊吧待办-Android-v1.5.apk`（或 `聊吧待办-v1.5.apk`）传到 Android 手机（Android 7.0 / API 24 及以上）
2. 在手机上点击安装
3. 系统可能提示「允许安装未知来源应用」，按提示开启即可

这是 **debug 版 APK**，可直接安装使用，无需签名。

## 移动端做过的适配

- 界面改为单列布局、占满屏幕，隐藏桌面窗口按钮
- 输入框、按钮、文字尺寸按手机触摸优化
- 导出功能改为：**优先调起系统分享**（可分享到微信等），失败时自动复制到剪贴板
- 数据保存在应用本地（localStorage），卸载应用会清除
- **系统闹钟提醒**：使用 Capacitor Local Notifications，设置后 App 关闭也能到点提醒
- **公众号原生直连**：CapacitorHttp 走 OkHttp，带微信 UA、无浏览器 CORS 限制，直接从微信服务器读取正文（需在 `capacitor.config.json` 中 `plugins.CapacitorHttp.enabled=true` 才生效）

## v1.5 修复
- 日期解析（大后天 / 下下周一 / 非法日期判无效）、负责人与地点边界、提醒长周期分段、URL 注入防护等 14 项缺陷修复

## 在电脑上重新打包

项目目录结构：
```
chat-todo-android/
├── www/                  # 网页源码（改功能改这里）
│   ├── index.html        # 导入页
│   ├── todos.html        # 待办页
│   ├── styles.css
│   ├── extraction.js     # 待办提取引擎
│   ├── data.js / notify.js / files.js / paste.js / todos.js
│   └── vendor/           # pdf.js / mammoth
├── android/              # Android 原生工程
├── capacitor.config.json # Capacitor 配置（含 CapacitorHttp 启用）
└── package.json
```

改完 `www/` 里的代码后重新打包：
```bash
cd chat-todo-android
npx cap sync android
cd android
./gradlew assembleDebug
```
产物在 `android/app/build/outputs/apk/debug/app-debug.apk`。

> 环境提示：本项目构建环境用 Java 20 + Gradle 8.14.3 + Android SDK 36。由于 Capacitor 与 local-notifications 对 Java 版本要求不一致，构建配置中已统一把 `sourceCompatibility` / `targetCompatibility` / `jvmToolchain` 改为 `20`（涉及 `node_modules/@capacitor/android/capacitor/build.gradle`、`android/app/capacitor.build.gradle`、`android/capacitor-cordova-android-plugins/build.gradle`），并且依赖仓库已指向腾讯镜像。**注意：执行 `npx cap sync` 后这些 Java 版本改动会被覆盖，需要重新改回 20 再构建。**

## 生成正式签名版（上架应用商店用）

debug 版不能上架。生成正式版需要：
1. 生成签名密钥：`keytool -genkey -v -keystore my-release-key.jks -keyalg RSA -keysize 2048 -validity 10000 -alias my-key`
2. 在 `android/app/build.gradle` 里配置 `signingConfigs`
3. 执行 `./gradlew assembleRelease`

如果不需要上架，自用 debug 版完全够用。
